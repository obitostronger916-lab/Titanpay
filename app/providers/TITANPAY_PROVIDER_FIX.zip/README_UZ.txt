TITANPAY — provider modul yo'llarini tuzatish

Ushbu arxivdagi ikkita faylni GitHub repozitoriyasidagi aynan shu joylarga yuklang:
- app/providers/base.py
- app/providers/none.py

Keyin GitHub'da quyidagi eski takroriy faylni o'chiring:
- app/providers/init.py

MUHIM:
- app/providers/__init__.py faylini O'CHIRMANG. U kerak.
- app/base.providers/ papkasidagi eski fayllarni hozircha o'chirmang.
- To'lov provayderi hali ulanmagan; bu tuzatish haqiqiy to'lovni qabul qilmaydi.
- ONESTATE RP API integratsiyasi ham bu arxivga kiritilmagan.

GitHub mobil saytida fayl qo'shish:
1. Repozitoriyani oching.
2. app/providers papkasiga kiring.
3. Add file → Upload files ni tanlang.
4. Arxivdan app/providers ichidagi base.py va none.py fayllarini tanlab yuklang.
5. Commit changes ni bosing.
6. So'ng init.py faylini ochib, Delete this file orqali o'chiring va commit qiling.

Bu faqat kerakli fayllar patchi; loyiha to'liq testdan o'tkazilgan degani emas.
